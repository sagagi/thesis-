% Function: evaluateFitness.m
% Evaluate fitness using sum square error

function fitness = evaluateFitness(population, X, k)
    numIndividuals = size(population, 1);
    fitness = zeros(numIndividuals, 1);
    
    for i = 1:numIndividuals
        % Select features based on the binary representation
        selectedFeaturesIdx = find(population(i, :) == 1);
        if isempty(selectedFeaturesIdx)
            fitness(i) = inf; % Penalize solutions with no features selected
            continue;
        end
        selectedData = X(:, selectedFeaturesIdx);
        
        % Perform k-means clustering
        [~, ~, sumD] = kmeans(selectedData, k);
        
        % Calculate sum square error
        fitness(i) = sum(sumD.^2);
    end
end
