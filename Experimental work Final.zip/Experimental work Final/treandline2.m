% Sample Data
datasets = {'WBC', 'Ionosphere', 'Wine', 'Dermatology'};
method1_accuracy = [95.89, 93.40, 96.85, 97.70];
method2_accuracy = [96.03, 88.80, 96.85, 98.60];
method3_accuracy = [94.50, 91.00, 97.00, 98.00]; % Data for Method 3

% Convert Dataset Names to Numerical Values
x_num = 1:length(datasets);

% Create Figure
figure;
hold on;

% Plot Data
plot(x_num, method1_accuracy, 'o-', 'DisplayName', 'Method 1', 'MarkerSize', 8);
plot(x_num, method2_accuracy, 's-', 'DisplayName', 'Method 2', 'MarkerSize', 8);
plot(x_num, method3_accuracy, 'd-', 'DisplayName', 'Method 3', 'MarkerSize', 8);

% Fit Polynomial Trend Lines (Linear)
p1 = polyfit(x_num, method1_accuracy, 1);
p2 = polyfit(x_num, method2_accuracy, 1);
p3 = polyfit(x_num, method3_accuracy, 1);

% Generate Trend Line Data
y_fit1 = polyval(p1, x_num);
y_fit2 = polyval(p2, x_num);
y_fit3 = polyval(p3, x_num);

% Plot Trend Lines
plot(x_num, y_fit1, 'r--', 'DisplayName', 'Trend Line for Method 1', 'LineWidth', 2);
plot(x_num, y_fit2, 'b--', 'DisplayName', 'Trend Line for Method 2', 'LineWidth', 2);
plot(x_num, y_fit3, 'g--', 'DisplayName', 'Trend Line for Method 3', 'LineWidth', 2);

% Customize Plot
xlabel('Datasets');
ylabel('Accuracy (%)');
title('Accuracy by Method');
legend('show');
grid on;
set(gca, 'XTick', x_num, 'XTickLabel', datasets);

% Display Figure
hold off;
