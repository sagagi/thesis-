% Function: calculateMetrics.m
% Calculate various evaluation metrics

function [accuracy, precision, recall, f1Score, auc, mcc] = calculateMetrics(actual, predicted, scores)
    % Calculate accuracy
    accuracy = sum(actual == predicted) / numel(actual);
    
    % Initialize variables for precision, recall, and F1 score
    tp = sum(actual == 1 & predicted == 1);
    fp = sum(actual == 0 & predicted == 1);
    fn = sum(actual == 1 & predicted == 0);
    
    % Calculate precision
    if (tp + fp) > 0
        precision = tp / (tp + fp);
    else
        precision = 0;
    end
    
    % Calculate recall
    if (tp + fn) > 0
        recall = tp / (tp + fn);
    else
        recall = 0;
    end
    
    % Calculate F1 score
    if (precision + recall) > 0
        f1Score = 2 * (precision * recall) / (precision + recall);
    else
        f1Score = 0;
    end
    
    % Calculate AUC (Area Under the ROC Curve)
    if nargin > 2 && ~isempty(scores) && size(scores, 2) > 1
        [~, ~, ~, auc] = perfcurve(actual, scores(:,2), 1);
    else
        auc = NaN; % AUC requires scores or probabilities
    end
    
    % Calculate Matthews Correlation Coefficient (MCC)
    tp = sum(actual == 1 & predicted == 1);
    tn = sum(actual == 0 & predicted == 0);
    fp = sum(actual == 0 & predicted == 1);
    fn = sum(actual == 1 & predicted == 0);
    
    numerator = (tp * tn) - (fp * fn);
    denominator = sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn));
    if denominator > 0
        mcc = numerator / denominator;
    else
        mcc = 0;
    end
end
