% Function: predictClassifiers.m
% Predict classes using trained classifiers

function [treePred, nbPred, knnPred, svmPred] = predictClassifiers(treeClassifier, nbClassifier, knnClassifier, svmClassifier, data)
    treePred = predict(treeClassifier, data);
    nbPred = predict(nbClassifier, data);
    knnPred = predict(knnClassifier, data);
    svmPred = predict(svmClassifier, data);
end
