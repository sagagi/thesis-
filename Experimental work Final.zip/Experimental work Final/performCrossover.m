% Function: performCrossover.m
% Perform crossover operation on the population

function newPopulation = performCrossover(population, crossoverRate)
    numBats = size(population, 1);
    numFeatures = size(population, 2);
    
    newPopulation = population;
    
    for i = 1:numBats
        if rand < crossoverRate
            % Select a random bat individual for crossover
            randIdx = randi(numBats);
            
            % Select a random crossover point
            crossoverPoint = randi(numFeatures);
            
            % Perform crossover
            newPopulation(i, :) = [population(i, 1:crossoverPoint), population(randIdx, crossoverPoint+1:end)];
        end
    end
end
