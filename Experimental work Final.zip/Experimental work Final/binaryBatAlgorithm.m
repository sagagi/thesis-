% Function: binaryBatAlgorithm.m
% Performs unsupervised feature selection using Binary Bat Algorithm and k-means clustering

function [bestFeatures, bestAccuracy] = binaryBatAlgorithm(X, y, numBats, maxIterations, pulseRate, loudness, crossoverRate, k, kFold)
    % Initialize pulse frequency, pulse rate, and loudness for each bat
    pulseFrequency = rand(numBats, 1) * 2;
    pulseRates = rand(numBats, 1);
    loudness = rand(numBats, 1);
    
    % Number of samples and features in the dataset
    numSamples = size(X, 1);
    numFeatures = size(X, 2);
    
    % Initialize best features and its accuracy
    bestFeatures = [];
    bestAccuracy = 0;
    
    % Perform Binary Bat Algorithm feature selection for a maximum of 'maxIterations' iterations
    for iter = 1:maxIterations
        % Initialize population of bat individuals
        population = randi([0 1], numBats, numFeatures);
        
        % Perform k-means clustering for each bat individual
        for i = 1:numBats
            % Select features based on the binary representation
            selectedFeaturesIdx = find(population(i, :) == 1);
            if isempty(selectedFeaturesIdx)
                continue; % Skip if no features selected
            end
            selectedData = X(:, selectedFeaturesIdx);
            
            % Perform k-means clustering
            [~, ~, sumD] = kmeans(selectedData, k);
            
            % Update the position of the bat using the modified binary bat approach
            population(i, :) = updateBatPosition(population(i, :), sumD, pulseRate);
        end
        
        % Perform crossover operation
        population = performCrossover(population, crossoverRate);
        
        % Evaluate fitness of each individual
        fitnessValues = evaluateFitness(population, X, k);
        
        % Select the best individual based on fitness
        [~, bestIdx] = min(fitnessValues);
        bestIndividual = population(bestIdx, :);
        
        % Select the features based on the best individual
        selectedFeaturesIdx = find(bestIndividual == 1);
        if isempty(selectedFeaturesIdx)
            continue; % Skip if no features selected
        end
        selectedData = X(:, selectedFeaturesIdx);
        
        % Perform classification using the selected features and evaluate accuracy
        accuracies = zeros(kFold, 1);
        precisions = zeros(kFold, 1);
        recalls = zeros(kFold, 1);
        f1Scores = zeros(kFold, 1);
        cv = cvpartition(y, 'KFold', kFold);
        
        for fold = 1:kFold
            trainIdx = training(cv, fold);
            testIdx = test(cv, fold);
            
            % Train classifier
            classifier = fitctree(selectedData(trainIdx, :), y(trainIdx));
            
            % Predict classes
            pred = predict(classifier, selectedData(testIdx, :));
            
            % Calculate accuracy
            accuracies(fold) = sum(pred == y(testIdx)) / numel(y(testIdx));
            
            % Calculate precision, recall, and F1 score
            [precisions(fold), recalls(fold), f1Scores(fold)] = calculateMetrics(y(testIdx), pred);
        end
        
        % Calculate mean accuracy
        meanAccuracy = mean(accuracies);
        meanPrecision = mean(precisions);
        meanRecall = mean(recalls);
        meanF1Score = mean(f1Scores);
        
        % Update the best features if the current accuracy is higher
        if meanAccuracy > bestAccuracy
            bestFeatures = selectedFeaturesIdx;
            bestAccuracy = meanAccuracy;
        end
    end
end
