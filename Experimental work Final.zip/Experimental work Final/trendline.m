% Sample Data for Number of Features Selected
datasets = {'WBC', 'Ionosphere', 'Wine', 'Dermatology'};
eufs_bba_features = [2, 5, 2, 10];
ufs_mbb_features = [3, 12, 5, 16];
ufs_aco_features = [5, 14, 5, 25];

% Convert Dataset Names to Numerical Values
x_num = 1:length(datasets);

% Create Figure
figure;
hold on;

% Plot Data for Each Method
plot(x_num, eufs_bba_features, 'o-', 'DisplayName', 'EUFS-BBA', 'MarkerSize', 8);
plot(x_num, ufs_mbb_features, 's-', 'DisplayName', 'UFS-MBBA', 'MarkerSize', 8);
plot(x_num, ufs_aco_features, 'd-', 'DisplayName', 'UFS-ACO', 'MarkerSize', 8);

% Fit Polynomial Trend Lines (Linear)
p1 = polyfit(x_num, eufs_bba_features, 1);
p2 = polyfit(x_num, ufs_mbb_features, 1);
p3 = polyfit(x_num, ufs_aco_features, 1);

% Generate Trend Line Data
y_fit1 = polyval(p1, x_num);
y_fit2 = polyval(p2, x_num);
y_fit3 = polyval(p3, x_num);

% Plot Trend Lines
plot(x_num, y_fit1, 'r--', 'DisplayName', 'Trend Line for EUFS-BBA', 'LineWidth', 2);
plot(x_num, y_fit2, 'b--', 'DisplayName', 'Trend Line for UFS-MBBA', 'LineWidth', 2);
plot(x_num, y_fit3, 'g--', 'DisplayName', 'Trend Line for UFS-ACO', 'LineWidth', 2);

% Customize Plot
xlabel('Datasets');
ylabel('Number of Features Selected');
title('Number of Features Selected by Algorithm Across Different Datasets');
legend('show');
grid on;
set(gca, 'XTick', x_num, 'XTickLabel', datasets);

% Display Figure
hold off;
