% Function: updateBatPosition.m
% Update bat position using modified binary bat approach

function newPosition = updateBatPosition(currentPosition, sumD, pulseRate)
    newPosition = currentPosition;
    
    % Perform local search
    for i = 1:numel(newPosition)
        if rand < pulseRate
            newPosition(i) = ~newPosition(i);
        end
    end
    
    % Perform global search
    [~, maxIdx] = max(sumD);
    newPosition(maxIdx) = 1;
    
    % Ensure at least one feature is selected
    if sum(newPosition) == 0
        [~, minIdx] = min(sumD);
        newPosition(minIdx) = 1;
    end
end
